from django.contrib import admin
from .models import Collection,Piece

admin.site.register(Collection)
admin.site.register(Piece)



# Register your models here.
